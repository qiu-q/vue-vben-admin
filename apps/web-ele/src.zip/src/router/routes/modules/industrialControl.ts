import type { RouteRecordRaw } from 'vue-router';
import { $t } from '#/locales';

const controlRoutes: RouteRecordRaw[] = [
  {
    meta: {
      icon: 'lucide:tv',
      order: 0,
      title: '大屏',
    },
    name: 'ControlScreen',
    path: '/control/screen',
    component: () => import('#/views/control/big-screen/index.vue'),
    meta: {
      affixTab: true,
      icon: 'lucide:tv',
      title: '大屏',
    },
  },
  {
    meta: {
      icon: 'lucide:network',
      order: 1,
      title: '拓扑图',
    },
    name: 'NetworkTopology',
    path: '/control/topology',
    component: () => import('#/views/control/network-topology/index.vue'),
    meta: {
      icon: 'lucide:network',
      title: '拓扑图',
    },
  },
];

export default controlRoutes;
