<template>
  <div class="sensor-cluster">
    <Handle type="target" position="top" />
    <div class="label">{{ data.label }}</div>
    <Handle type="source" position="bottom" />
  </div>
</template>

<script setup lang="ts">
import { Handle } from '@vue-flow/core'
import { defineProps } from 'vue'

interface Props {
  data: { id: string; type: string; label: string }
}
const { data } = defineProps<Props>()
</script>

<style scoped>
.sensor-cluster {
  position: relative;
  width: 140px;
  height: 60px;
  background: rgba(0,255,100,0.2);
  border: 2px dashed #0f0;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #0f0;
  font-weight: bold;
}
</style>
