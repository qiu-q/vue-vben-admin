<template>
  <div class="diagram-container">
    <VueFlow
      v-model:nodes="nodes"
      v-model:edges="edges"
      :node-types="nodeTypes"
      :edge-types="edgeTypes"
      :fit-view-on-init="true"
      :nodes-draggable="true"
      :edges-updatable="true"
      class="flow-wrapper"
      @connect="onConnect"
      @nodes-change="onNodesChange"
      @edges-change="onEdgesChange"
    >
      <Background />
      <Controls />
    </VueFlow>
  </div>
</template>


<script setup lang="ts">
import { ref, onMounted, markRaw } from 'vue'
import {
  VueFlow,
  addEdge,
  applyNodeChanges,
  applyEdgeChanges,
} from '@vue-flow/core'
import type {
  Node,
  Edge,
  Connection,
  NodeChange,
  EdgeChange,
} from '@vue-flow/core'

// 自定义组件相对路径
import DeviceNode    from '../../../components/DeviceNode.vue'
import SensorCluster from '../../../components/SensorCluster.vue'
import CustomEdge    from '../../../components/CustomEdge.vue'

// 模拟 JSON 数据
const dataRaw = {
  devices: [
    { id: 'pc_01',  type: 'pc',      label: '上位机',     x:  50, y: 100 },
    { id: 'sw_01',  type: 'switch',  label: '交换机',     x: 300, y: 100 },
    { id: 'plc_01', type: 'plc',     label: 'PLC-01',     x: 550, y:  50 },
    { id: 'gw_01',  type: 'gateway', label: 'ODOT 网关',  x: 550, y: 150 },
    { id: 'sns_grp',type: 'sensor-cluster', label: '8× 传感器', x: 800, y: 100 }
  ],
  links: [
    { from: 'pc_01', to: 'sw_01' },
    { from: 'sw_01', to: 'plc_01' },
    { from: 'sw_01', to: 'gw_01' },
    { from: 'gw_01', to: 'sns_grp' }
  ],
}

// 响应式节点与连线
const nodes = ref<Node[]>([])
const edges = ref<Edge[]>([])

// 使用 markRaw 避免组件被转成响应式对象
const nodeTypes = markRaw({
  device: DeviceNode,
  'sensor-cluster': SensorCluster,
})
const edgeTypes = markRaw({ custom: CustomEdge })

// 页面初始化
onMounted(() => {
  // 初始化节点
  nodes.value = dataRaw.devices.map((d) => ({
    id: d.id,
    type: d.type === 'sensor-cluster' ? 'sensor-cluster' : 'device',
    position: { x: d.x, y: d.y },
    data: { id: d.id, label: d.label, type: d.type },
  }))
  // 初始化连线
  edges.value = dataRaw.links.map((l) => ({
    id: `${l.from}-${l.to}`,
    source: l.from,
    target: l.to,
    type: 'custom',
  }))
})

// 支持用户拖拽新建连线
function onConnect(connection: Connection) {
  edges.value = addEdge({ ...connection, type: 'custom' }, edges.value)
}

// 节点位置变更时，应用更新
function onNodesChange(changes: NodeChange[]) {
  nodes.value = applyNodeChanges(changes, nodes.value)
}

// 边的变更（删除/更新）
function onEdgesChange(changes: EdgeChange[]) {
  edges.value = applyEdgeChanges(changes, edges.value)
}
</script>

<style scoped>
.diagram-container {
  width: 100%;
  height: 100vh;
}
.flow-wrapper {
  width: 100%;
  height: 100%;
  background: #00111a;
}
</style>
